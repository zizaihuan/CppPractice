#include "logger.h"
std::string Logger::get_time(){
    time_t now_time=time(NULL);
    tm*  t_tm = localtime(&now_time);  
    return asctime(t_tm);
};

void Logger::recode(const std::string&& str){
    std::unique_lock<std::mutex> io_lock(io_m);
    o<<get_time()<<"\t"<<"Recode\t"<<str<<std::endl;
};
void Logger::error(const std::string&& str){
    o<<get_time()<<"\t"<<"Error\t"<<str<<std::endl;
};
void Logger::panic(const std::string&& str){
    o<<get_time()<<"\t"<<"Panic\t"<<str<<std::endl;
};