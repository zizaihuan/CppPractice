#include <iostream>
#include <mutex>
#include <time.h>

// 特点：
// 1. 可选打印格式
// 2. 打印对多线程安全

#ifndef Logger_H
#define Logger_H

class Logger
{
public:
    Logger(std::ostream& o):o(o){};
    std::ostream& o;
    void recode(const std::string&& str);
    void error(const std::string&& str);
    void panic(const std::string&& str);
private:
    std::mutex io_m;
    std::string get_time();
};

#endif