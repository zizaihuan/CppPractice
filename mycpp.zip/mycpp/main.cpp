#include "global.h"
std::ofstream log_file("log.txt");
Logger l(log_file);
bool ready = false;
std::condition_variable cv;
std::mutex ready_m;
void p(int i){
	std::unique_lock<std::mutex> ready_lock(ready_m);
	cv.wait(ready_lock,[](){return ready;});
	if(i%3==0){
		l.recode("这是recode.");
	}else if(i%3 ==1){
		l.error("这是error.");
	}else{
		l.panic("这是panic.");
	}
}

int main(){
	std::vector<std::thread> v;
	for (size_t i = 0; i < 10; i++)
	{
		v.push_back(std::thread(p,i));
	}
	ready = true;
	cv.notify_all();
	for (auto &&one : v)
	{
		one.join();
	}
}